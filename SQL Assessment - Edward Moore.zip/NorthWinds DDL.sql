create table Categories (
  CategoryID int NOT NULL PRIMARY KEY,
  CategoryName nvarchar(15) NOT NULL,
  Description ntext,
  Picture image);

CREATE TABLE Customers (
  CustomerID nchar(5) NOT NULL PRIMARY key,
  CompanyName nvarchar(40) NOT NULL,
  ContactName nvarchar(30),
  ContactTitle nvarchar(30),
  Address nvarchar(60),
  City nvarchar(15),
  Region nvarchar(15),
  PostalCode nvarchar(10), 
  Country nvarchar(15),
  Phone nvarchar(24),
  Fax nvarchar(24));

CREATE table CustomerDemographics (
  CustomerTypeID nchar(10) NOT NULL PRIMARY KEY,
  CustomerDesc ntext);

CREATE TABLE Employees (
  EmployeeID int NOT NULL PRIMARY KEY,
  LastName nvarchar(20) NOT NULL,
  FirstName nvarchar(10) NOT NULL,
  Title nvarchar(30),
  TitleOfCourtesy nvarchar(25),
  BirthDate datetime,
  HireDate datetime,
  Address nvarchar(60),
  City nvarchar(15),
  Region nvarchar(15),
  PostalCode nvarchar(10),
  Country nvarchar(15),
  HomePhone nvarchar(24),
  Extension nvarchar(4),
  Photo image,
  Notes ntext,
  ReportsTo int, 
  PhotoPath nvarchar(255),
  CONSTRAINT FK_ReportsTo_Emp FOREIGN KEY (ReportsTo)
  	REFERENCES Employees(EmployeeID));

CREATE TABLE Region (
  RegionID int NOT NULL PRIMARY KEY,
  RegionDescription nchar(50) NOT NULL);

Create TABLE Shippers (
  ShipperID int NOT NULL PRIMARY KEY,
  CompanyName nvarchar(40) NOT NULL,
  Phone nvarchar(24));

Create TABLE Suppliers (
  SupplierID int NOT NULL PRIMARY KEY,
  CompanyName nvarchar(40) NOT NULL,
  ContactName nvarchar(30),
  ContactTitle nvarchar(30),
  Address nvarchar(60),
  City nvarchar(15),
  Region nvarchar(15),
  PostalCode nvarchar(10),
  Country nvarchar(15),
  Phone nvarchar(24),
  Fax nvarchar(24),
  HomePage ntext);

CREATE TABLE Products (
  ProductID int NOT NULL PRIMARY KEY,
  ProductName nvarchar(40) NOT NULL,
  SupplierID int,
  CategoryID int, 
  QuantityPerUnit nvarchar(20),
  UnitPrice money, 
  UnitsInStock smallint,
  UnitsOnOrder smallint,
  ReorderLevel smallint,
  Discontinued bit,
  CONSTRAINT FK_SupplierID_Prod FOREIGN KEY (SupplierID)
  	REFERENCES Supplier(SupplierID),
  CONSTRAINT FK_CategoryID_Prod FOREIGN KEY (CategoryID)
  	REFERENCES Categories(CategoryID));

create table Territories (
  TerritoryId nvarchar(20) NOT NULL PRIMARY KEY,
  TerritoryDescription nchar(50) NOT NULL,
  RegionID int,
  CONSTRAINT FK_RegionID_Terr FOREIGN KEY (RegionID)
    REFERENCES Region(RegionID));

CREATE TABLE Orders (
  OrderID int NOT NULL PRIMARY KEY,
  CustomerID nchar(5),
  EmployeeID int,
  OrderDate datetime,
  RequiredDate datetime,
  ShippedDate datetime,
  ShipVia int,
  Freight money,
  ShipName nvarchar(40),
  ShipAddress nvarchar(60),
  ShipCity nvarchar(15),
  ShipRegion nvarchar(15),
  ShipPostalCode nvarchar(10),
  ShipCountry nvarchar(15),
  CONSTRAINT FK_CustomerID_Ord FOREIGN KEY (CustomerID)
  	REFERENCES Customers(CustomerID),
  CONSTRAINT FK_EmployeeID_Ord FOREIGN KEY (EmployeeID)
  	REFERENCES Employees(EmployeeID),
  CONSTRAINT FK_ShipVia_Ord FOREIGN key (ShipVia)
  	REFERENCES Shippers(ShipperID));
  
CREATE TABLE Order_Details (
  OrderID int NOT NULL,
  ProductID int NOT NULL,
  UnitPrice money NOT NULL,
  Quantity smallint NOT NULL,
  Discount real NOT NULL,
  PRIMARY KEY (OrderID, ProductID),
  CONSTRAINT FK_ProductID_OD FOREIGN KEY (ProductID)
  	REFERENCES Products(ProductId));
 
CREATE TABLE CustomerCustomerDemo (
  CustomerID nchar(5) NOT NULL,
  CustomerTypeID nchar(10) NOT NULL,
  PRIMARY KEY (CustomerID, CustomerTypeID)
  CONSTRAINT FK_CustomerID_CCD FOREIGN KEY (CustomerID)
  	REFERENCES Customers(CustomerID),
  CONSTRAINT FK_CustomerTypeID_CCD FOREIGN KEY (CustomerTypeID)
  	REFERENCES CustomerDemographics(CustomerTypeID));

CREATE TABLE EmployeeTerritories (
  EmployeeID int NOT NULL,
  TerritoryID nvarchar(20) NOT NULL,
  PRIMARY KEY (EmployeeID, TerritoryID)
  CONSTRAINT FK_EmployeeID_ET FOREIGN KEY (EmployeeID)
  	REFERENCES Employees(EmployeeID),
  CONSTRAINT FK_TerritoryID_ET FOREIGN KEY (TerritoryID)
  	REFERENCES Territories(TerritoryID));
  