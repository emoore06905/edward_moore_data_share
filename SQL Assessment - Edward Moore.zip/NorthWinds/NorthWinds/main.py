#connect to database

import sqlite3
import pandas as pd
dbName = "C:\\Program Files\\SQLiteStudio\\Northwinds"
#dbName = "C:\\Users\\emoor\\OneDrive\\Desktop\\Northwinds\\Northwinds"
conn = sqlite3.connect(dbName)

#Categories.xlsx
excel = 'Categories.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into categories values (?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Categories Loaded")

#Regions.xlsx
excel = 'Regions.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into region values (?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Regions Loaded")

#Shippers.xlsx
excel = 'Shippers.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into shippers values (?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Shippers Loaded")

#Suppliers.xlsx
excel = 'Suppliers.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into suppliers values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Suppliers Loaded")

#Employees.xlsx
excel = 'Employees.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into employees values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Employees Loaded")

#Territories.xlsx
excel = 'Territories.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into territories values (?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Territories Loaded")

#EmployeeTerritories.xlsx
excel = 'EmployeeTerritories.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into employeeterritories values (?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("EmployeeTerritories Loaded")

#Customers.xlsx
excel = 'Customers.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into customers values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Customers Loaded")

"""

#CustomerDemographics.xlsx
excel = 'CustomerDemographics.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into customerdemographics values (?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("CustomerDemographics Loaded")

#CustomerCustomerDemo.xlsx
excel = 'CustomerCustomerDemo.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into customercustomerdemo values (?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("CustomerCustomerDemo Loaded")

"""

#Orders.xlsx
excel = 'Products.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into products values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Products Loaded")

#Orders.xlsx
excel = 'Orders.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into orders values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Orders Loaded")

#Order_Details.xlsx
excel = 'Order_Details.xlsx'
data = pd.read_excel(io=excel, sheet_name=0, header=0)

#print(data)
for i, r in data.iterrows():
    q = f"insert into order_details values (?, ?, ?, ?, ?)"
    v = tuple(r)
    rc = conn.execute(q,v)

conn.commit()
print("Order_Details Loaded")

conn.close()

