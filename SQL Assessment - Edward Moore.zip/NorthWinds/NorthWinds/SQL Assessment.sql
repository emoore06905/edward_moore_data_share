--Q1    top 10 orderid, orderdate, shippeddate, customerid, freight sorted by freight in descending order
select 
    orderid,
    orderdate,
    shippeddate,
    customerid,
    freight
from orders
order by freight desc
limit 10;

--Q2    all productname, unitprice, quantityperunit of products out of stock
select
    productname,
    unitprice, 
    quantityperunit
from products
where unitsinstock = 0;

--Q3    all contactname, address, city of customers not from germany, mexico or spain
select
    contactname,
    address,
    city,
    country
from customers
where ifnull(country,'') not in('Germany','Mexico','Spain');

--Q4    all orderdate, shippeddate, customerid placed on 21 May 1996
select
    orderdate,
    shippeddate,
    customerid
from orders
where strftime('%Y-%m-%d',orderdate) = '1996-05-21';

--Q5    all employeeid, orderid, customerid, requireddate, shippeddate where shipped was later than required
select
    employeeid,
    orderid,
    customerid,
    requireddate,
    shippeddate
from orders
where shippeddate > requireddate or (shippeddate is null and requireddate <= date('now'));

--Q6    all orders where freight cost more than 500
select
    *
from orders
where freight > 500;

--Q7    productname, unitsinstock, unitsonorder, reorderlevel
select
    productname,
    unitsinstock,
    unitsonorder,
    reorderlevel
from products
where unitsinstock < reorderlevel;

--Q8    orderid, total number of orderid as numberoforders from orderdetails groupd by orderid and sorted by number of orders in descending order
select
    orderid,
    count(orderid) as numberoforders
from order_details
group by orderid
order by 2 desc;

--Q9    contactname, contacttitle, companyname from customers with no Sales in title
select
    contactname,
    contacttitle,
    companyname
from customers
where upper(contacttitle) not like '%SALES%';

--Q10  Average UnitPrice rounded up to next whole number (averageprice), total price of units in stock (totalstock), and maximum number of orders (maxorder) from product
select
    round(avg(unitprice) + 0.5,0) as averageprice,
    sum(unitsinstock*unitprice) as totalstock,
    max(unitsonorder) as maxorder
from products;

--Q11    from orders table, customerid and sum of freight where sum of freight > 200
select
    customerid,
    sum(freight) as sumoffreight
from orders
group by customerid
having sum(freight) > 200;

--Q12    from order_details, order, and customers, get orderid, contactname, unitprice, quantity, discount with discount on every purchase
select
    ORD.orderid,
    CUS.contactname,
    ODT.unitprice,
    ODT.quantity,
    ODT.discount
from
    orders ORD
    inner join order_details ODT
        on ORD.orderid = ODT.orderid
    inner join customers CUS
        on ORD.customerid = CUS.customerid
where 
    ODT.discount > 0;
    
--Q13    top 10 (by number of orders) shippers for most-recent month.  Include Growth from previous  month, growth from 6 months ago, and rowth from 12 months ago
with 
SHIPSUMMARY as (
    select shipvia, 
    strftime('%Y-%m',shippeddate) as shipmonth,
    count(orderid) as numorders
    from orders
    group by shipvia, strftime('%Y-%m',shippeddate)),
CAL as (select
                shipvia,
                max(strftime('%Y-%m',orderdate)) as mostrecentmonth,
                max(strftime('%Y-%m',date(orderdate,'-1 MONTHS'))) as onemonthsago,
                max(strftime('%Y-%m',date(orderdate,'-6 MONTHS'))) as sixmonthsago,
                max(strftime('%Y-%m',date(orderdate,'-12 MONTHS'))) as twelvemonthsago
                from orders
                group by shipvia)

select 
    SHP.CompanyName, 
    CAL.mostrecentmonth,
    round(100*cast(CURR.numorders-CURRM1.numorders as real)/CURRM1.numorders,3) as previous_month_growth_pct,
    round(100*cast(CURR.numorders-CURRM6.numorders as real)/CURRM6.numorders,3) as six_month_growth_pct,
    round(100*cast(CURR.numorders-CURRM12.numorders as real)/CURRM12.numorders,3) as twelve_month_growth_pct
from
    CAL
    join shippers SHP
        on CAL.shipvia = SHP.shipperid 
    join SHIPSUMMARY CURR
        on CAL.shipvia = CURR.shipvia
        and CAL.mostrecentmonth = CURR.shipmonth
    left outer join SHIPSUMMARY CURRM1
        on CAL.shipvia = CURRM1.shipvia
        and CAL.onemonthsago = CURRM1.shipmonth
    left outer join SHIPSUMMARY CURRM6
        on CAL.shipvia = CURRM6.shipvia
        and CAL.sixmonthsago = CURRM6.shipmonth
    left outer join SHIPSUMMARY CURRM12
        on CAL.shipvia = CURRM12.shipvia
        and CAL.twelvemonthsago = CURRM12.shipmonth
order by CURR.numorders desc
LIMIT 10;
;



